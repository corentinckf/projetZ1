#ifndef __textures_h__
#define __textures_h__

void play_with_texture_1(SDL_Texture *my_texture, SDL_Window *window,SDL_Renderer *renderer);

#endif