This is a free 48x48 resize, made by dopan to be compatible with RPG Maker MV.

https://www.patreon.com/DopanDeveloping
https://www.deviantart.com/magicoktarin
